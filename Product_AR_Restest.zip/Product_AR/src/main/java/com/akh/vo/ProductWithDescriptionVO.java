package com.akh.vo;

import com.akh.entity.ProductEntity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductWithDescriptionVO {
	
	private ProductEntity productEntity;
	private ProductDescriptionVO productDescription;

}
