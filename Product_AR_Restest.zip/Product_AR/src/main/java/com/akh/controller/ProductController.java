package com.akh.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.akh.entity.ProductEntity;
import com.akh.service.ProductServiceImpl;
import com.akh.vo.ProductWithDescriptionVO;

@RestController
@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	private ProductServiceImpl productServiceImpl;
	
	@GetMapping("/byid/{id}")
	public Optional<ProductEntity> getProductById(@PathVariable Integer id){
		return productServiceImpl.getById(id);
	}
	
	@GetMapping("/bytype/{type}")
	public List<ProductEntity> getProductByType(@PathVariable String type){
		return productServiceImpl.getByType(type);
	}
	
	@PostMapping("/addproduct")
	public void addProduct(@RequestBody ProductEntity product) {
		productServiceImpl.addProduct(product);
	}
	
	@GetMapping("/productwithdescription/{id}")
	public ProductWithDescriptionVO getProductWithDescription(@PathVariable Integer id) {
		return productServiceImpl.getProductWithDescription(id);
	}

}
