package com.akh.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akh.entity.ProductEntity;
import com.akh.repository.ProductRepository;
import com.akh.vo.ProductDescriptionVO;
import com.akh.vo.ProductWithDescriptionVO;


@Service
public class ProductServiceImpl implements ProductService{

	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private ProductDescriptionClient client;
	
	@Override
	public Optional<ProductEntity> getById(Integer productId) {
		return productRepository.findById(productId);
	}

	@Override
	public List<ProductEntity> getByType(String type) {
		
		return productRepository.findByType(type);
	}

	@Override
	public void addProduct(ProductEntity product) {
		productRepository.save(product);
		
	}

	
	@Override
	public ProductWithDescriptionVO getProductWithDescription(Integer productId) {
		Optional<ProductEntity> optional = productRepository.findById(productId);
		if(optional.isPresent()) {
			ProductEntity product = optional.get();
			Integer descriptionId = product.getProductId();
			ProductDescriptionVO description = client.getDescription(descriptionId);
			ProductWithDescriptionVO pdVO =new ProductWithDescriptionVO();
			pdVO.setProductEntity(product);
			pdVO.setProductDescription(description);
			return pdVO;
		}
		return null;
	}
	

}
