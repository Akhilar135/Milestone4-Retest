package com.akh.service;

import java.util.List;
import java.util.Optional;

import com.akh.entity.ProductEntity;
import com.akh.vo.ProductWithDescriptionVO;

public interface ProductService {

	public Optional<ProductEntity> getById(Integer productId);
	public List<ProductEntity> getByType(String type);
	public void addProduct(ProductEntity product);
	public ProductWithDescriptionVO getProductWithDescription(Integer productId);
}
